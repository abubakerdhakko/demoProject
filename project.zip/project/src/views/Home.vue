<template>
  <div class="home">
    <Creds />
    <Addcreds />
  </div>
</template>



<script>
import Creds from "../components/Credentials.vue";
import Addcreds from "../components/AddCreds.vue";


export default {
  name: "home",
  components: {
    Creds,
    Addcreds,
  },
};
</script>
