<template>
  <div class="home">
          <h1>This is an Contact page</h1>
  </div>
</template>

<script>
// @ is an alias to /srcimport HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'contact',
  components: {
    // HelloWorld
  }
}
</script>
