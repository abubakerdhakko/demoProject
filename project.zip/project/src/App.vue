

<template>
  <div id="app">
    <div class="container">
      <div>
        <Tabs></Tabs>
        <router-view />
      </div>

    </div>
  </div>
</template>

<script>


import Tabs from "./components/Tabs.vue";

export default {
  name: "app",
  components: {
    Tabs,


  },
};
</script>

<style>

</style>
