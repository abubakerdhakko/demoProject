<template>
  <div>
    <h3>Credentials</h3>
    <div class="legend">
      <span>Company Name</span>
      <span> Job responsibility </span>
      <span> <span class="complete-box"></span> manager </span>
    </div>

    <div class="main-flex" v-for="Cred in allCreds" :key="Cred.id">
      <input type="text" :value="Cred.title" />

      <input type="text" ref="last_name" :value="Cred.id" />
      <input type="text" :value="Cred.id" />
      <i @click="deleteCreds(Cred.id)" class="fas fa-trash-alt"></i>
      <!-- <i @click="edit(Cred)" class="fas fa-edit"></i> -->
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";

export default {
  name: "Todos",
  data() {
    return {
      Cred: {
        id: "",
        title: "",
      },
    };
  },
  methods: {
    ...mapActions(["fetchCreds", "deleteCreds", "updateCred"]),
    edit(value) {
      console.log("credss", value);

      const updCred = {
        id: value.id,
        title: value.title,
      };
      console.log("updCred", updCred);
      this.updateCred(updCred);
    },
  },
  computed: mapGetters(["allCreds"]),
  created() {
    this.fetchCreds();
  },
};
</script>

<style scoped>
.todos {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 1rem;
}

/* .Cred {
  border: 1px solid #ccc;
  background: #41b883;
  padding: 1rem;
  border-radius: 5px;
  text-align: center;
  position: relative;
  cursor: pointer;
} */

.main-flex {
  display: flex;
  text-align: center;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}
.main-flex span {
  border: 1px solid #ccc;
  flex-basis: 25%;
  padding: 16px;
  margin: 0px 10px 10px;
}
.legend {
  display: flex;
  justify-content: space-around;
  margin-bottom: 1rem;
}
.legend span {
  flex-basis: 25%;
}

@media (max-width: 500px) {
  .todos {
    grid-template-columns: 1fr;
  }
}
</style>
