<template>
  <div class="">
    <div class="Bg">
      <div class="tab">
          <router-link to="/">Home 1</router-link>
          <router-link to="/about">About 2</router-link>
                 <router-link to="/contact">Contact 3</router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>