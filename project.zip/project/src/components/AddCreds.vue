<template>
  <div>
    <h3>Add</h3>
    <div class="add">
      <form @submit="onSubmit">
        <input type="text" v-model="title" placeholder="Add Creds...">
        <input type="submit" value="Add">
      </form>
    </div>
  </div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  name: "Addcreds",
  data() {
    return {
      title: ""
    };
  },
  methods: {
    ...mapActions(["Addcreds"]),
    onSubmit(e) {
      e.preventDefault();
      this.Addcreds(this.title);
    }
  }
};
</script>

<style scoped>
form {
  display: flex;
}

input[type="text"] {
  flex: 10;
  padding: 10px;
  border: 1px solid #41b883;
  outline: 0;
}

input[type="submit"] {
  flex: 2;
  background: #41b883;
  color: #fff;
  border: 1px #41b883 solid;
  cursor: pointer;
}
</style>
